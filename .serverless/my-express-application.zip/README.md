# serverless_tutorial
working through Serverless' tutorial:
https://serverless.com/blog/serverless-express-rest-api/

## Installations
npm install serverless -g

npm init -f

npm install --save express serverless-http
